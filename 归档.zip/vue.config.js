module.exports = {
  publicPath: '/suning'
}