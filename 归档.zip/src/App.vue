<template>
  <div id="app">
    <transition-router/>
  </div>
</template>

<style lang="scss">
  html,
  body {
    position: fixed;
    width: 100%;
    height: 100%;
    margin: 0;
  }
  #app {
    font-family: "Helvetica Neue", Helvetica, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "微软雅黑", Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    color: #606266;

    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;

    .trans {
      transition: all .3s;
    }

    .trans-fast {
      transition: all .1s;
    }

    .trans-slow {
      transition: all .7s;
    }

    .text-ellipsis{
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    // 每个页面默认的padding
    .container-padding{
      padding: 15px;
      box-sizing: border-box;
    }
    // 每个页面头的样式
    .container-head{
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0 15px 15px;
      border-bottom: 1px solid #ddd;
      .lead{
        font-size: 32px;
      }
    }
    // 修改表格中搜索框居中
    // 默认样式看着不太居中
    .cell{
      .el-input{
        transform: translateY(3px);
      }
    }
    // 全局默认pagination上边距和定义居中
    .pagination {
      margin-top: 15px;
      text-align: center;
    }
  }

  .graceful-statement-popper.el-tooltip__popper[role=tooltip] {
    color: #606266;
    border-color: #ddd;
    .popper__arrow{
      border-bottom-color: #ddd !important;
    }
  }
</style>
<script>
import TransitionRouter from './components/TransitionRouter'
export default {
  components: { TransitionRouter }
}
</script>
