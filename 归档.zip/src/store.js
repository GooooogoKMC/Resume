import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    userName: ''
  },
  getters: {
    userName: state => state.userName
  },
  mutations: {
    USER_NAME: (state, payload) => {
      state.userName = payload
    }
  },
  actions: {
    setUserName ({ commit }, payload) {
      commit('USER_NAME', payload)
    }
  }
})
