<template>
  <header id="top-nav">
    <graceful-statement class="graceful-statement"/>
    <el-dropdown class="drop-down">
      <span class="el-dropdown-link">
        欢迎，{{$store.getters.userName}}<i class="el-icon-arrow-down el-icon--right"></i>
      </span>
      <el-dropdown-menu slot="dropdown">
        <el-dropdown-item @click.native="dialogState = true">修改密码</el-dropdown-item>
        <el-dropdown-item @click.native="signout">退出登录</el-dropdown-item>
      </el-dropdown-menu>
    </el-dropdown>
    <el-dialog
      :title="`修改${$store.getters.userName}的密码`"
      :visible.sync="dialogState"
      :before-close="handleCloseChangePasswordDialog"
      width="600px">
      <el-form :model="passwordForm" label-position="left" label-width="100px"
               :rules="passwordFormRules" status-icon ref="passwordForm">
        <el-form-item label="新密码" required prop="password">
          <el-input v-model="passwordForm.password" autocomplete="off" show-password></el-input>
        </el-form-item>
        <el-form-item label="确认密码" required prop="checkPassword">
          <el-input v-model="passwordForm.checkPassword" autocomplete="off" show-password></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="handleCloseChangePasswordDialog">取 消</el-button>
        <el-button type="primary" @click="handleSubmitChangePassword">确 定</el-button>
      </span>
    </el-dialog>
  </header>
</template>

<script>
import GracefulStatement from './GracefulStatement'
export default {
  name: 'TopNav',
  components: { GracefulStatement },
  data () {
    let validatePass = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入密码'))
      } else {
        if (this.passwordForm.checkPassword !== '') {
          this.$refs.passwordForm.validateField('checkPassword')
        }
        callback()
      }
    }
    let validatePass2 = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请再次输入密码'))
      } else if (value !== this.passwordForm.password) {
        callback(new Error('两次输入密码不一致!'))
      } else {
        callback()
      }
    }
    return {
      passwordForm: {
        password: '',
        checkPassword: ''
      },
      passwordFormRules: {
        password: [
          { validator: validatePass, trigger: ['blur', 'change'] },
          { min: 6, max: 16, message: '长度在 6 到 16 个字符', trigger: ['blur'] }
        ],
        checkPassword: [
          { validator: validatePass2, trigger: ['blur', 'change'] }
        ]
      },
      dialogState: false
    }
  },
  watch: {
    dialogState (state) {
      if (!state) {
        this.$refs['passwordForm'].resetFields()
      }
    }
  },
  methods: {
    handleCloseChangePasswordDialog () {
      this.dialogState = false
    },
    handleSubmitChangePassword () {
      this.$refs['passwordForm'].validate((valid) => {
        if (valid) {
          this.$axios.put(this.$api.password, {
            password: this.passwordForm.password
          })
            .then(res => {
              if (res.state) {
                this.$notify({
                  title: '修改成功',
                  type: 'success',
                  message: `操作成功`,
                  position: 'top-right'
                })
                this.dialogState = false
              }
            })
        } else return false
      })
    },
    signout () {
      this.$axios.post(this.$api.signout)
        .then(() => {
          this.$router.push({ name: 'signin' })
        })
    }
  }
}
</script>

<style scoped lang="scss">
  #top-nav {
    display: flex;
    justify-content: space-between;
    align-items: center;
    height: 30px;
    padding: 10px 25px;
    background: #ffffff;
    border-bottom: 1px solid #eeeeee;

    .graceful-statement{
      flex: 1;
      text-align: left;
      overflow: hidden;
    }

    .drop-down{
      margin-left: 25px;
      cursor: pointer;
      &:focus{
        outline: none;
      }
    }
  }
</style>
