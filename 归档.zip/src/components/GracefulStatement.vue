<template>
  <div id="graceful-statement" class="text-ellipsis">
      <el-tooltip :content="statement" placement="bottom" effect="light" enterable popper-class="graceful-statement-popper">
        <span>{{statement}}</span>
      </el-tooltip>
  </div>
</template>

<script>
export default {
  name: 'GracefulStatement',
  data () {
    return {
      activeIndex: 0,
      timer: undefined,
      statements: [
        '地球上有77亿人，204个国家，809个岛屿。两个人遇见概率是2920万之ー，幸运如我，在最好的时光，刚好遇见了你!',
        '一杯浊酒以清风，听山水道不尽风流，一曲离愁以明月，听繁星诉不尽哀求。',
        '时光氤氲，愿你被世界温柔以待。',
        '我是这样喜欢你。于是看山是你，看水是你。长河落日是你，大漠孤烟是你。绿杨荫里白沙是你，姑苏城外寒山是你。风雨萧萧是你，桃之夭夭是你。因为你，所以白风暖了杨柳岸，春水绿了竹叶沿。',
        '我喜欢春天的樱花，夏天的矢车菊，秋天的百里香，冬天的腊梅，还有每天的你。',
        '归去，也无风雨也无晴。',
        '许我剪一段时光吧，剪一段有淡淡芳香的时光，寄给你，让你每一个平凡的日子，都如花开。',
        '你是我平淡余生的不将就，也是我藏至心底的不可说。',
        '喜欢一座城市，我想大抵是因为这座城市生活着你喜欢的人或者是有一段无关快乐和忧伤的回忆。也恰恰是因为这样，这座城市的一切都变得与众不同。一草，一木总关情，甚至是城市的气息，都是自己想要的味道。',
        '期待遇见一个人，从此暗中有光。',
        '他发现了人类行为的一大法则，自己还不知道——那就是，为了要使一个大人或小孩极想干某样事情，只需要设法把那件事情弄得不易到手就行了。',
        '凡是一个人非做不可的事，都叫做“工作”；凡不是一个人非做不可的事，都叫做＂娱乐＂。',
        '仲夏夜，清风徐徐吹来，明月追赶晚霞，早早爬过山头，挂在中天，那月光似乎带着一股清凉，驱赶着酷日留下的余热。',
        '谁不会休息，谁就不会工作。 —— 列宁',
        '在年轻人的颈项上，没有什么东西能比事业心这颗灿烂的宝珠更迷人的了。 —— 哈菲兹',
        '事业无穷年。 —— 韩愈',
        '当一个人用工作去迎接光明，光明很快就会来照耀着他。 —— 冯学峰',
        '时间是一切财富中最宝贵的财富。 —— 德奥弗拉斯多',
        '从不浪费时间的人，没有工夫抱怨时间不够。 —— 杰弗逊',
        '人类的全部历史都告诫有智慧的人，不要笃信时运，而应坚信思想。 —— 爱献生',
        '劳动和人，人和劳动，这是所有真理的父母亲。 —— 苏霍姆林斯基',
        '理想是人生的太阳。 —— 德莱赛',
        '要使别人喜欢你，首先你得改变对人的态度，把精神放得轻松一点，表情自然，笑容可掬，这样别人就会对你产生喜爱的感觉了。——卡耐基',
        '谁给我一滴水，我便回报他整个大海。——华梅'
      ]
    }
  },
  computed: {
    statement () {
      return this.statements[this.activeIndex]
    }
  },
  methods: {
    randomIndex () {
      this.activeIndex = Math.floor(Math.random() * this.statements.length)
    }
  },
  created () {
    this.randomIndex()
    this.timer = setInterval(this.randomIndex, 10 * 60 * 1000)
  },
  destroyed () {
    clearInterval(this.timer)
  }
}
</script>

<style scoped lang="scss">
#graceful-statement{
    span {
      outline: none !important;

      &:focus,
      &:active {
        outline: none;
      }
    }
}
</style>
