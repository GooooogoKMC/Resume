<template>
  <div id="page-container">
    <left-nav/>
    <transition-router class="content"/>
  </div>
</template>

<script>
import LeftNav from './LeftNav'
import TransitionRouter from './TransitionRouter'
export default {
  name: 'PageContainer',
  components: { TransitionRouter, LeftNav }
}
</script>

<style scoped lang="scss">
#page-container{
  flex: 1;
  display: flex;
  justify-content: flex-start;

  .content{
    flex: 1;
  }
}
</style>
