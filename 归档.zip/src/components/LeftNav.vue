<template>
  <div id="left-nav" class="trans" :class="{fold:!menuExpand}" >
    <ul>
      <router-link class="trans-fast" tag="li" v-for="item in menu" :key="item.name" :to="{name: item.name}">
        <i :class="item.icon"></i>
        <span v-if="menuExpand" class="text-ellipsis">{{item.showName}}</span>
      </router-link>
    </ul>
    <div class="operate">
      <i class="el-icon-download trans" v-if="menuExpand" @click="toggleMenuExpand"></i>
      <i class="el-icon-upload2 trans"  v-else @click="toggleMenuExpand"></i>
    </div>
  </div>
</template>

<script>
export default {
  name: 'LeftNav',
  data () {
    return {
      menuExpand: true,
      menu: [{
        name: 'home',
        showName: '首页',
        icon: 'el-icon-house'
      }, {
        name: 'staff',
        showName: '员工管理',
        icon: 'el-icon-user'
      }, {
        name: 'position',
        showName: '职位管理',
        icon: 'el-icon-suitcase'
      }, {
        name: 'system',
        showName: '系统配置',
        icon: 'el-icon-setting'
      }, {
        name: 'shop',
        showName: '店铺管理',
        icon: 'el-icon-box'
      }, {
        name: 'verify',
        showName: '用户申请审核',
        icon: 'el-icon-s-data'
      }, {
        name: 'order',
        showName: '订单查询',
        icon: 'el-icon-s-data'
      }, {
        name: 'statement',
        showName: '对账单',
        icon: 'el-icon-s-data'
      }, {
        name: 'performance',
        showName: '门店业绩',
        icon: 'el-icon-s-data'
      }]
    }
  },
  methods: {
    toggleMenuExpand () {
      this.menuExpand = !this.menuExpand
    }
  }
}
</script>

<style scoped lang="scss">
#left-nav{
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: flex-start;
  width: 180px;
  border-right: 1px solid #eeeeee;
  background: #fff;
  &.fold{
    width: 50px;
    li{
      justify-content: center;
      width: 100%;
      padding-right: 0;
      padding-left: 0;
    }
  }
  ul{
    flex: 1;
    width: 100%;
    margin: 0;
    padding: 0;
    overflow: auto;
    li{
      display: flex;
      justify-content: flex-start;
      align-items: center;
      height: 56px;
      padding: 20px 30px 20px 25px;
      margin: 0;
      box-sizing: border-box;
      cursor: pointer;
      list-style-type: none;
      &:hover{
        background: #d9ecff;
      }
      &.router-link-exact-active{
        background: #ecf5ff;
        color: #409eff;
      }
      i{
        margin-right: 5px;
      }
    }
  }
  .operate{
    position: relative;
    width: 100%;
    height: 50px;
    i{
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%) scale(1) rotate(90deg);
      padding: 30px 10px;
      cursor: pointer;
      &:hover{
        transform: translate(-50%, -50%) scale(1.2) rotate(90deg);
      }
    }
  }
}
</style>
