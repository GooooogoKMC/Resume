<template>
  <div class="transition-router">
    <transition name="fade">
      <router-view/>
    </transition>
  </div>
</template>

<script>
// 通用路由fade效果
export default {
  name: 'TransitionRouter'
}
</script>

<style scoped lang="scss">
.transition-router{
  position: relative;
  width: 100%;
  height: 100%;
  overflow: hidden;

  .fade-enter-active,
  .fade-leave-active {
    position: absolute;
    left: 0;
    top: 0;
    right: 0;
    transition: all .7s ease-in-out;
  }
  .fade-enter {
    transform: translateX(5%);
    opacity: 0;
  }
  .fade-leave-to {
    transform: translateX(-5%);
  }
  .fade-leave-active {
    opacity: 0;
  }
}
</style>
