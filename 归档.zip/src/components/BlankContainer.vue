<template>
  <transition-router/>
</template>

<script>
// 作用：作为通用子页的承载，添加路由动画
import TransitionRouter from './TransitionRouter'
export default {
  name: 'BlankContainer',
  components: { TransitionRouter }
}
</script>

<style scoped>

</style>
