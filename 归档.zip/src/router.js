import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

export default new Router({
  mode: 'history',
  base: '/suning/', /* process.env.BASE_URL + */
  routes: [{
    path: '/signin',
    name: 'signin',
    component: () => import(/* webpackChunkName: "home" */'./views/Signin')
  }, {
    path: '/welcome',
    name: 'welcome',
    component: () => import(/* webpackChunkName: "home" */'./views/Welcome')
  }, {
    path: '/',
    name: 'index',
    component: () => import(/* webpackChunkName: "home" */'./views/Index'),
    redirect: {
      name: 'home'
    },
    children: [{
      path: 'home',
      name: 'home',
      component: () => import(/* webpackChunkName: "home" */'./views/Home')
    }, {
      path: 'reset',
      name: 'reset',
      component: () => import(/* webpackChunkName: "home" */'./views/Home'),
      children: [
        {
          path: 'password',
          name: 'password',
          component: () => import(/* webpackChunkName: "home" */'./views/Home')
        }
      ]
    }, {
      path: 'management',
      name: 'management',
      component: () => import(/* webpackChunkName: "blank-container" */'./components/BlankContainer'),
      redirect: {
        name: 'shop'
      },
      children: [{
        path: 'shop',
        name: 'shop',
        component: () => import(/* webpackChunkName: "home" */'./views/management/Shop')
      }, {
        path: 'staff',
        name: 'staff',
        component: () => import(/* webpackChunkName: "home" */'./views/management/Stuff')
      }, {
        path: 'position',
        name: 'position',
        component: () => import(/* webpackChunkName: "home" */'./views/management/Position')
      }, {
        path: 'system',
        name: 'system',
        component: () => import(/* webpackChunkName: "home" */'./views/management/System')
      }, {
        path: 'verify', // 用户审核
        name: 'verify',
        component: () => import(/* webpackChunkName: "home" */'./views/Home')
      }, {
        path: '*',
        component: () => import(/* webpackChunkName: "not-fond" */'./views/NotFound')
      }]
    }, {
      path: 'qrcode',
      name: 'qrcode',
      component: () => import(/* webpackChunkName: "home" */'./views/Home')
    }, {
      path: 'order', // 订单查询
      name: 'order',
      component: () => import(/* webpackChunkName: "home" */'./views/Home')
    }, {
      path: 'analyze', // 业绩
      name: 'analyze',
      component: () => import(/* webpackChunkName: "home" */'./views/Home'),
      children: [
        {
          path: 'statement', // 对账单
          name: 'statement',
          component: () => import(/* webpackChunkName: "home" */'./views/Home')
        }, {
          path: 'performance', // 门店业绩
          name: 'performance',
          component: () => import(/* webpackChunkName: "home" */'./views/Home')
        }, {
          path: '*',
          component: () => import(/* webpackChunkName: "not-fond" */'./views/NotFound')
        }
      ]
    }]
  }, {
    path: '*',
    component: () => import(/* webpackChunkName: "not-fond" */'./views/NotFound')
  }]
})
