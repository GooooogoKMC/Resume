const server = 'http://127.0.0.1:8081'
const application = '/api/admin'
const methods = ['signin', 'signout', 'shop', 'stuff', 'order',
  'auth', 'password', 'position', 'permission']
let api = {}

for (let i of methods) {
  Object.defineProperty(api, i, {
    configrable: true,
    enumerable: true,
    get: () => server + application + '/' + i,
    set: () => {
      throw (new Error('Value can not be set!'))
    }
  })
}

export default api
