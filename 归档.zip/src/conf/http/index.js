import axios from 'axios'
import { Loading, Notification } from 'element-ui'
import api from './api'
// import vueCookies from 'vue-cookies'
import router from '../../router'
// TODO 修复 如果同时由多个请求，配置里的如是否需要loading等会出现错乱，因为后一个请求的配置会影响到前一个请求的问题
export default {
  install (Vue) {
    // 创建axios实例
    const axiosInstance = axios.create({
      baseURL: '',
      timeout: 100 * 1000, // 100s 超时时间
      headers: {
        withCredentials: true
      }
    })
    // 创建loading实例
    let loadingInstance
    let loadingInstanceConf
    let createLoadingInstance = () => {
      if (!loadingInstanceConf.needLoading) return
      loadingInstance = Loading.service({
        target: loadingInstanceConf.target || document.body,
        lock: loadingInstanceConf.lock || loadingInstanceConf.lock,
        text: loadingInstanceConf.text || '加载中，请稍后',
        spinner: loadingInstanceConf.spinner || 'el-icon-loading',
        background: loadingInstanceConf.background || 'rgba(255, 255, 255, 0.7)'
      })
    }
    let closeLoadingInstance = () => {
      if (!loadingInstanceConf.needLoading) return
      loadingInstance.close()
    }
    // 配置axios请求预处理
    axiosInstance.interceptors.request.use(config => {
      // 在发送请求之前做些什么
      return config
    }, function (error) {
      // 对请求错误做些什么
      return Promise.reject(error)
    })
    // 配置axios响应预处理
    axiosInstance.interceptors.response.use(function (response) {
      // 对响应数据做点什么
      closeLoadingInstance()
      if (response.data.state) {
        return response.data
      } else if (response.data.needReSignin) {
        router.push({ name: 'signin' })
        Notification({
          title: '认证失败！',
          type: 'error',
          message: `${response.data.message}`,
          position: 'top-right'
        })
      } else {
        Notification({
          title: '请求失败！',
          type: 'error',
          message: `${response.data.message}`,
          position: 'top-right'
        })
        return null
      }
    }, function (error) {
      // 对响应错误做点什么
      closeLoadingInstance()
      Notification({
        title: '糟糕，出错了！',
        type: 'error',
        dangerouslyUseHTMLString: true,
        message: `<strong>获取数据的时候发生了一些问题：</strong><b/><p>${error.message}</p>`,
        position: 'top-right'
      })
      return Promise.reject(error)
    })
    // 加载动画默认配置
    const loadingInstanceDefaultConf = {
      needLoading: true,
      target: document.body,
      lock: true,
      text: '加载中，请稍后',
      spinner: 'el-icon-loading',
      background: 'rgba(255, 255, 255, 0.7)'
    }
    // 请求方式
    const RequestType = {
      GET: 'GET',
      POST: 'POST',
      PUT: 'PUT',
      DELETE: 'DELETE'
    }
    // 请求方法
    const request = (url, params, conf) => method => {
      loadingInstanceConf = Object.assign({}, loadingInstanceDefaultConf, conf)
      createLoadingInstance()
      switch (method) {
        case RequestType.GET:
          return axiosInstance.get(url, { params })
        case RequestType.POST:
          return axiosInstance.post(url, { ...params })
        case RequestType.PUT:
          return axiosInstance.put(url, { ...params })
        case RequestType.DELETE:
          return axiosInstance.delete(url, { params })
        default:
          console.error('Request method err')
          break
      }
    }
    // 添加到Vue实例上的方法
    Vue.prototype.$axios = {
      get: (url, params, conf) => request(url, params, conf)(RequestType.GET),
      post: (url, params, conf) => request(url, params, conf)(RequestType.POST),
      put: (url, params, conf) => request(url, params, conf)(RequestType.PUT),
      'delete': (url, params, conf) => request(url, params, conf)(RequestType.DELETE)
    }
    // 添加API URL
    Vue.prototype.$api = api
  }
}
