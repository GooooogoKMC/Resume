<template>
  <div id="index">
    <top-nav/>
    <page-container/>
  </div>
</template>

<script>
import TopNav from '../components/TopNav'
import PageContainer from '../components/PageContainer'
export default {
  name: 'Index',
  components: { PageContainer, TopNav },
  created () {
    this.$axios.get(this.$api.auth, {}, {
      needLoading: false
    }).then(res => {
      this.$store.dispatch('setUserName', res.data.name)
    })
  }
}
</script>

<style scoped lang="scss">
  #index{
    width: 100%;
    height: 100%;

    display: flex;
    flex-direction: column;
    justify-content: flex-start;
  }
</style>
