<template>
  <div id="home">
    123
  </div>
</template>

<script>
// @ is an alias to /src
export default {
  name: 'home',
  components: {}
}
</script>

<style scoped lang="scss">

</style>
