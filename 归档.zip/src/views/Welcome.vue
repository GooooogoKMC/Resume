<template>
  <div id="welcome">
    <div class="text">
      欢迎，{{$store.getters.userName}}
    </div>
  </div>
</template>

<script>
export default {
  name: 'Welcome',
  mounted () {
    setTimeout(() => {
      this.$router.replace({
        name: 'home'
      })
    }, 1300)
  }
}
</script>

<style scoped lang="scss">
  #welcome{
    position: absolute;
    width: 100%;
    height: 100%;
    .text{
      position: absolute;
      top: 33%;
      left: 50%;
      font-size: 50px;
      text-align: center;
      transform: translate(-50%, -50%);
    }
  }
</style>
