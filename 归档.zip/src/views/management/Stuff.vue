<template>
  <div id="staff" class="container-padding">
    <header class="container-head">
      <span class="lead">员工管理</span>
      <el-button plain icon="el-icon-circle-plus-outline" size="small" >新增员工</el-button>
    </header>
  </div>
</template>

<script>
export default {
  name: 'Stuff'
}
</script>

<style scoped lang="scss">

</style>
