<template>
  <div id="shop" class="container-padding">
    <header class="container-head">
      <span class="lead">店铺管理</span>
      <el-button plain icon="el-icon-circle-plus-outline" size="small"
                 @click="handleAddNewSHop">新建店铺</el-button>
    </header>
    <el-table
      id="shop-table"
      class="shop-table"
      max-height="650px"
      :data="shopData">
      <el-table-column type="expand" fixed>
        <template slot-scope="props">
          <div class="table-expand">
            <el-image fit="contain" :src="props.row.qrcode">
              <div slot="placeholder" class="image-slot">
                加载中<span class="dot">...</span>
              </div>
              <div slot="error" class="image-slot">
                <i class="el-icon-picture-outline"></i>
              </div>
            </el-image>
          </div>
        </template>
      </el-table-column>
      <el-table-column
        prop="name"
        label="店铺名称"
        width="300">
      </el-table-column>
      <el-table-column
        prop="position"
        label="店铺位置"
        min-width="200">
        <template slot-scope="scope">
          <i class="el-icon-location-outline"></i>
          <span style="margin-left: 10px">{{ scope.row.position }}</span>
        </template>
      </el-table-column>
      <el-table-column
        prop="charger_name"
        label="负责人"
        min-width="150">
      </el-table-column>
      <el-table-column
        prop="charger_phone"
        label="联系方式"
        min-width="200">
        <template slot-scope="scope">
          <i class="el-icon-phone-outline"></i>
          <span style="margin-left: 10px">{{ scope.row.charger_phone }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" fixed="right" width="200">
        <template slot="header" slot-scope="scope">
          <el-input
            :fix="scope"
            v-model="search"
            size="mini"
            placeholder="输入店铺名称搜索"/>
        </template>
        <template slot-scope="scope">
          <el-button
            @click.native.prevent="handleEditRow(scope.$index, scope.row)"
            size="mini">
            编辑
          </el-button>
          <el-button
            size="mini"
            type="danger"
            @click.native.prevent="handleDeleteRow(scope.$index, scope.row)">删除
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      class="pagination"
      @size-change="handleSizeChange"
      @current-change="handlePageCurrentChange"
      :current-page="currentPage"
      :page-sizes="pageSizes"
      :page-size="pageSize"
      layout="jumper, prev, pager, next, total, sizes"
      :total="total">
    </el-pagination>
    <el-dialog
      :title="dialogName"
      :visible.sync="dialogState"
      :before-close="handleCloseShopInfoDialog"
      width="600px">
      <el-form :model="shopInfo" label-position="left" label-width="100px"
               :rules="shopRules" status-icon ref="shopForm">
        <el-form-item label="店铺名称" required prop="name">
          <el-input v-model="shopInfo.name" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="店铺位置" required prop="position">
          <el-input v-model="shopInfo.position" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="负责人" required prop="charger_name">
          <el-input v-model="shopInfo.charger_name" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="联系方式" required prop="charger_phone">
          <el-input v-model.number="shopInfo.charger_phone" autocomplete="off"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="handleCloseShopInfoDialog">取 消</el-button>
        <el-button type="primary" @click="handleSubmitAddShop">确 定</el-button>
      </span>
    </el-dialog>
    <el-dialog
      title="提示"
      :visible.sync="deleteConfirm"
      width="300px">
      是否确认删除{{deleteRowData ? deleteRowData.name : ''}}这个店铺？
      <span slot="footer" class="dialog-footer">
        <el-button @click="deleteConfirm = false">取 消</el-button>
        <el-button type="primary" @click="handleDeleteRowConfirm">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
export default {
  name: 'Shop',
  data () {
    let validatePhoneNumber = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入店铺负责人联系方式'))
      } else if (!Number.isInteger(value) && Number.isNaN(parseInt(value))) {
        callback(new Error('店铺负责人联系方式必须为数字值'))
      } else if (!(/^1[3456789]\d{9}$/.test(value))) {
        callback(new Error('请输入正确格式的手机号码'))
      } else {
        callback()
      }
    }
    return {
      currentPage: 1,
      pageSizes: [10, 20, 50, 100, 200],
      pageSize: 10,
      total: 0,
      search: '',
      shopData: [],
      dialogState: false,
      deleteConfirm: false,
      dialogType: true, // true 新增 false 编辑
      deleteRowData: null,
      shopInfo: {
        shop_id: '',
        name: '',
        position: '',
        charger_name: '',
        charger_phone: ''
      },
      shopRules: {
        name: [
          { required: true, message: '请输入店铺名称', trigger: ['blur', 'change'] },
          { min: 3, max: 16, message: '长度在 3 到 16 个字符', trigger: ['blur', 'change'] }
        ],
        position: [
          { required: true, message: '请输入店铺地址', trigger: ['blur', 'change'] },
          { min: 3, max: 32, message: '长度在 3 到 32 个字符', trigger: ['blur', 'change'] }
        ],
        charger_name: [
          { required: true, message: '请输入店铺负责人名称', trigger: ['blur', 'change'] },
          { min: 3, max: 8, message: '长度在 3 到 8 个字符', trigger: ['blur', 'change'] }
        ],
        charger_phone: [
          { validator: validatePhoneNumber, trigger: ['blur', 'change'] }
        ]
      },
      canSearch: false, // input后不立即搜索，使用定时器延时一段时间，没有继续输入则搜索
      canSearchTimer: null
    }
  },
  computed: {
    dialogName () {
      return this.dialogType ? '新增店铺' : '编辑店铺信息'
    }
  },
  watch: {
    pageSize () {
      this.getShopData()
    },
    currentPage () {
      this.getShopData()
    },
    search () {
      if (this.canSearchTimer) clearTimeout(this.canSearchTimer)
      this.canSearchTimer = setTimeout(() => {
        this.getShopData()
      }, 1000)
    },
    dialogState () {
      if (!this.dialogState) {
        this.$refs['shopForm'].resetFields()
        Object.keys(this.shopInfo).forEach(key => {
          console.log(key)
          this.shopInfo[key] = ''
        })
      }
    }
  },
  methods: {
    handleSizeChange (size) {
      this.pageSize = size
    },
    handlePageCurrentChange (page) {
      this.currentPage = page
    },
    handleEditRow (index, row) {
      Object.keys(this.shopInfo).forEach(key => {
        this.shopInfo[key] = row[key]
      })
      this.dialogState = true
      this.dialogType = false
      this.$nextTick(() => this.$refs['shopForm'].validate())
    },
    handleDeleteRow (index, row) {
      this.deleteRowData = row
      this.deleteConfirm = true
    },
    handleDeleteRowConfirm () {
      this.$axios.delete(this.$api.shop, {
        shop_id: this.deleteRowData.shop_id
      })
        .then(res => {
          if (res.state) {
            this.getShopData()
            this.deleteConfirm = false
          }
        })
    },
    handleAddNewSHop () {
      this.dialogState = true
      this.dialogType = true
    },
    handleCloseShopInfoDialog () {
      this.dialogState = false
    },
    handleSubmitAddShop () {
      this.$refs['shopForm'].validate((valid) => {
        if (valid) {
          let params = Object.assign({}, this.shopInfo, {
            page: this.currentPage,
            limit: this.pageSize
          })
          if (!params.shop_id) delete params.shop_id
          // 没有shop_id -> 新增
          this.$axios[params.shop_id ? 'put' : 'post'](this.$api.shop, params)
            .then(res => {
              if (res.state) {
                this.$notify({
                  title: this.dialogType ? '新建店铺成功' : '保存店铺信息成功！',
                  type: 'success',
                  message: `操作成功`,
                  position: 'top-right'
                })
                this.dialogState = false
                this.getShopData()
              }
            })
        } else return false
      })
    },
    getShopData () {
      this.$axios.get(this.$api.shop, {
        page: this.currentPage,
        size: this.pageSize,
        search: this.search
      }, {
        target: '#shop-table'
      }).then(res => {
        this.total = res.data.total
        this.shopData = res.data.rows
      })
    }
  },
  mounted () {
    this.getShopData()
  }
}
</script>

<style scoped lang="scss">
  #shop {
    display: flex;
    flex-direction: column;
    height: 100%;

    .shop-table {
      flex: none;
      padding: 0 15px;

      .table-expand {
        display: flex;
        justify-content: center;
        align-items: center;
      }
    }
  }
</style>
