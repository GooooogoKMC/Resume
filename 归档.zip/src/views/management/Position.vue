<template>
  <div id="position" class="container-padding">
    <header class="container-head">
      <span class="lead">职位管理</span>
      <el-button plain icon="el-icon-circle-plus-outline" size="small"
                  @click="handleAddNewPosition">新增职位</el-button>
    </header>
    <el-table
      id="position-table"
      class="position-table"
      max-height="650px"
      :data="positionData">
      <el-table-column
        prop="name"
        label="职位名称">
      </el-table-column>
      <el-table-column align="center" fixed="right" width="200">
        <template slot="header" slot-scope="scope">
          <el-input
            :fix="scope"
            v-model="search"
            size="mini"
            placeholder="输入职位名称搜索"/>
        </template>
        <template slot-scope="scope">
          <el-button
            @click.native.prevent="handleEditRow(scope.$index, scope.row)"
            size="mini">
            编辑
          </el-button>
          <el-button
            size="mini"
            type="danger"
            @click.native.prevent="handleDeleteRow(scope.$index, scope.row)">删除
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      class="pagination"
      @size-change="handleSizeChange"
      @current-change="handlePageCurrentChange"
      :current-page="currentPage"
      :page-sizes="pageSizes"
      :page-size="pageSize"
      layout="jumper, prev, pager, next, total, sizes"
      :total="total">
    </el-pagination>
  </div>
</template>

<script>
export default {
  name: 'Position',
  data () {
    return {
      positionData: [],
      total: 0,
      currentPage: 1,
      pageSizes: [10, 20, 50, 100, 200],
      pageSize: 10,
      positionInfo: {
        position_id: '',
        name: ''
      },
      search: '',
      canSearch: false, // input后不立即搜索，使用定时器延时一段时间，没有继续输入则搜索
      canSearchTimer: null,
      permission: {
        api: [],
        page: []
      }
    }
  },
  watch: {
    pageSize () {
      this.getPositionData()
    },
    currentPage () {
      this.getPositionData()
    },
    search () {
      if (this.canSearchTimer) clearTimeout(this.canSearchTimer)
      this.canSearchTimer = setTimeout(() => {
        this.getPositionData()
      }, 1000)
    }
  },
  methods: {
    handleAddNewPosition () {
      console.log('add new position')
    },
    handleEditRow (index, row) {
      return null
    },
    handleDeleteRow (index, row) {
      return null
    },
    handleDeleteRowConfirm () {
      return null
    },
    handleSizeChange (size) {
      this.pageSize = size
    },
    handlePageCurrentChange (page) {
      this.currentPage = page
    },
    getPositionData () {
      return new Promise((resolve, reject) => {
        this.$axios.get(this.$api.position, {
          page: this.currentPage,
          size: this.pageSize,
          search: this.search
        }, {
          target: '#position-table'
        }).then(res => {
          this.total = res.data.total
          this.positionData = res.data.rows
          resolve()
        }).catch(err => {
          reject(err)
        })
      })
    },
    getPermissionData () {
      this.$axios.get(this.$api.permission, {}, {
        needLoading: false
      }).then(res => {
        this.permission.api = res.data.api
        this.permission.page = res.data.page
      })
    }
  },
  mounted () {
    this.getPositionData()
      .then(() => {
        this.getPermissionData()
      })
  }
}
</script>

<style scoped lang="scss">
  #position {
    .position-table {
      flex: none;
      padding: 0 15px;
    }
  }
</style>
