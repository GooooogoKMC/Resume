<template>
  <div id="system" class="container-padding">
    <header class="container-head">
      <span class="lead">系统配置</span>
    </header>
    <el-form ref="systemForm" label-width="120px" label-position="left">
      <el-form-item label="自动通过申请" prop="delivery">
        <el-switch v-model="systemForm.autoPassApply"></el-switch>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
export default {
  name: 'System',
  data () {
    return {
      systemForm: {
        autoPassApply: false
      }
    }
  }
}
</script>

<style scoped>

</style>
