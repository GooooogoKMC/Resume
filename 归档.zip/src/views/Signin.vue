<template>
  <div id="sign-in">
    <div class="title">苏宁小店</div>
    <el-form class="signin-form" status-icon :model="formData" :rules="formRules" ref="loginForm">
      <el-form-item prop="account">
        <el-input type="text" clearable v-model="formData.account" placeholder="请输入您的账号"
                  @keyup.enter.native="autoFocus" id="account"/>
      </el-form-item>
      <el-form-item prop="password">
        <el-input type="password" show-password v-model="formData.password" placeholder="请输入您的密码"
                  @keyup.enter.native="submit(true)" id="password"/>
      </el-form-item>
      <el-button class="signin-btn" :loading="loading" @click="submit(false)">登录</el-button>
    </el-form>
  </div>
</template>

<script>
export default {
  name: 'Signin',
  data () {
    return {
      accountFocus: false,
      passwordFocus: false,
      formData: {
        account: '',
        password: ''
      },
      formRules: {
        account: [
          { required: true, message: '请输入您的账号', trigger: ['blur', 'change'] },
          { min: 4, max: 16, message: '长度在 4 到 16 个字符', trigger: ['blur', 'change'] }

        ],
        password: [
          { required: true, message: '请输入您的密码', trigger: ['blur', 'change'] },
          { min: 4, max: 16, message: '长度在 4 到 16 个字符', trigger: ['blur', 'change'] }
        ]
      },
      loading: false
    }
  },
  methods: {
    autoFocus () {
      document.querySelector('#password').focus()
    },
    submit (needGlobalLoading) {
      console.log(needGlobalLoading)
      this.$refs['loginForm'].validate(valid => {
        if (valid) {
          this.loading = !needGlobalLoading
          this.$axios.post(this.$api.signin, {
            account: this.formData.account,
            password: this.formData.password
          }, {
            needLoading: needGlobalLoading
          }).then(res => {
            if (res.state) {
              this.loading = false
              this.$router.push({ name: 'welcome' })
              this.$store.dispatch('setUserName', res.data.name)
            }
          }).catch(() => {
            this.loading = false
          })
        }
      })
    }
  },
  mounted () {
    document.querySelector('#account').focus()
  }
}
</script>

<style scoped lang="scss">
#sign-in{
  position: absolute;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 100%;
  .title {
    margin: -200px 0 50px;
    font-size: 50px;
  }
  .signin-form{
    width: 450px;
    .signin-btn{
      width: 100%;
    }
  }
}
</style>
